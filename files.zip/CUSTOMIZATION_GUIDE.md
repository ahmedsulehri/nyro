# N450 Website - Customization Guide

## 🎨 How to Customize Your Website

### **Easy Changes (No coding needed):**

---

## 1. **Change Colors**

Open `index.html` and find this section (around line 30):

```css
:root {
    --primary: #1a1a1a;      /* Main dark color */
    --secondary: #ffffff;    /* White */
    --accent: #2563eb;       /* Blue (main accent) */
    --accent-light: #3b82f6; /* Light blue */
    --text: #1f2937;         /* Dark text */
    --text-light: #6b7280;   /* Light text */
    --border: #e5e7eb;       /* Borders */
    --bg-light: #f9fafb;     /* Light background */
}
```

**Examples:**
- Change `--accent: #2563eb;` to `#dc2626;` for red
- Change `--accent: #2563eb;` to `#059669;` for green
- Change `--primary: #1a1a1a;` to `#1e40af;` for blue theme

**Popular Color Codes:**
```
Red:     #dc2626
Green:   #059669
Purple:  #7c3aed
Orange:  #ea580c
Gold:    #d97706
```

---

## 2. **Change Text Content**

### Navigation Bar:
Find this section:
```html
<ul class="nav-links">
    <li><a href="#home">Home</a></li>
    <li><a href="#features">Features</a></li>
    <li><a href="#products">Products</a></li>
    <li><a href="#testimonials">Reviews</a></li>
</ul>
```

### Hero Section (Main Heading):
```html
<h1>Step Into <span>Excellence</span></h1>
<p class="hero-subtitle">Experience premium Pakistani footwear...</p>
```

Change these to your brand message.

### Product Names & Prices:
```html
<div class="product-category">Formal</div>
<div class="product-name">Executive Series</div>
<div class="product-price">Rs. 3,499</div>
```

Update product names and prices.

### Testimonials:
```html
<p class="testimonial-text">"N450 shoes are incredibly comfortable..."</p>
<h4>Ahmed Hassan</h4>
<p>Karachi, Sindh</p>
```

Add real customer reviews.

---

## 3. **Change Logo**

Replace `N450` with your brand name:

```html
<div class="logo">N450</div>
```

To: 
```html
<div class="logo">Your Brand Name</div>
```

**Or add a logo image:**
```html
<img src="logo.png" alt="Logo" style="height: 40px;">
```

---

## 4. **Change Shoe Emojis to Images**

Current:
```html
<div class="shoe-image">👟</div>
```

With an image:
```html
<div class="shoe-image">
    <img src="shoe.jpg" alt="Shoe" style="max-width: 100%; height: auto;">
</div>
```

---

## 5. **Update Statistics**

```html
<div class="stat-item">
    <span class="stat-number">50K+</span>
    <span class="stat-label">Happy Customers</span>
</div>
```

Change numbers based on your actual data.

---

## 6. **Modify Features**

Find and update:
```html
<div class="feature-card">
    <div class="feature-icon">🇵🇰</div>
    <h3>Made in Pakistan</h3>
    <p>Proudly crafted with local expertise...</p>
</div>
```

---

## 7. **Add New Sections**

### Add More Products:
Copy this and add it to the products section:
```html
<div class="product-card">
    <div class="product-image">👠</div>
    <div class="product-content">
        <div class="product-category">Women</div>
        <div class="product-name">Elegant Heel</div>
        <div class="product-price">Rs. 2,499</div>
        <button class="product-btn">Add to Cart</button>
    </div>
</div>
```

---

## 8. **Change Links**

Update social media and contact links:

```html
<div class="footer-section">
    <h3>Follow Us</h3>
    <ul>
        <li><a href="https://facebook.com/yourpage">Facebook</a></li>
        <li><a href="https://instagram.com/yourpage">Instagram</a></li>
        <li><a href="https://wa.me/923001234567">WhatsApp</a></li>
    </ul>
</div>
```

---

## 9. **Animation Speed**

Find animation definitions (around line 70) and adjust duration:

```css
@keyframes fadeInDown {
    from { opacity: 0; transform: translateY(-30px); }
    to { opacity: 1; transform: translateY(0); }
}
```

To make animations faster, change in HTML:
```css
animation: fadeInDown 0.5s ease-out;  /* Was 0.8s, now 0.5s */
```

**Speed values:**
- `0.3s` - Very fast
- `0.5s` - Fast
- `0.8s` - Normal
- `1s` - Slow
- `2s` - Very slow

---

## 10. **Button Colors**

```html
.btn-primary {
    background: var(--primary);  /* Change this */
    color: white;
}

.btn-primary:hover {
    background: var(--accent);   /* Change this */
}
```

---

## 11. **Font Changes**

The site uses:
- **Poppins** (Bold headings)
- **Inter** (Regular text)

To use different fonts:

1. Find this section:
```html
<link href="https://fonts.googleapis.com/css2?family=Poppins...&display=swap" rel="stylesheet">
```

2. Go to [fonts.google.com](https://fonts.google.com)
3. Pick your fonts
4. Copy the link and replace the above

---

## 12. **Spacing & Padding**

In CSS section, adjust spacing:

```css
.features {
    padding: 6rem 5%;  /* Change these numbers */
}
```

- Larger number = more space
- `6rem` = large spacing
- `3rem` = medium spacing
- `1rem` = small spacing

---

## 13. **Border Radius (Rounded Corners)**

```css
.feature-card {
    border-radius: 15px;  /* Change to 25px for rounder, 5px for sharper */
}
```

---

## 14. **Shadow Effects**

```css
box-shadow: 0 20px 50px rgba(0, 0, 0, 0.1);
```

- Smaller numbers = subtle shadow
- Larger numbers = strong shadow
- `0.1` = light shadow, `0.3` = dark shadow

---

## **Advanced Customizations:**

### Add Google Analytics:
Add this before `</body>`:
```html
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_ID"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'YOUR_GA_ID');
</script>
```

### Add WhatsApp Chat Button:
Add before `</body>`:
```html
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<a href="https://wa.me/923001234567?text=Hello%20N450" 
   style="position: fixed; bottom: 20px; right: 20px; z-index: 999; 
          background: #25d366; color: white; width: 60px; height: 60px; 
          border-radius: 50%; display: flex; align-items: center; 
          justify-content: center; font-size: 30px; text-decoration: none;">
   💬
</a>
```

---

## **SEO Optimization:**

Add this in the `<head>` section:

```html
<meta name="description" content="N450 - Premium Pakistani footwear with fast delivery and affordable luxury">
<meta name="keywords" content="shoes, Pakistan, footwear, N450, affordable, quality">
<meta name="author" content="N450">
<meta name="robots" content="index, follow">
```

---

## **Important Tips:**

✅ **Always backup** your original file before making changes
✅ **Test changes** in your browser before uploading
✅ **Use Find & Replace** to change text quickly (Ctrl+H)
✅ **Keep animations smooth** - don't make them too slow
✅ **Test on mobile** - make sure it looks good on phones
✅ **Compress images** before uploading (if using actual photos)

---

## **Common Mistakes to Avoid:**

❌ Don't remove closing tags `</tag>`
❌ Don't change color codes incorrectly
❌ Don't add too many animations
❌ Don't make text too small for mobile
❌ Don't forget to save changes

---

## **Need Help?**

If you make a mistake:
1. Use Ctrl+Z to undo
2. Or restore from your backup
3. Use a code editor like VS Code (free)

**Happy customizing! 🚀**
